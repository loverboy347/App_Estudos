# Catálogo de questões — Artrópodes, Equinodermos e Protocordados

**Fonte principal:** Blog do Prof. Djalma Santos (série "Testes de Zoologia"), https://djalmasantos.wordpress.com/

## Conteúdo do pacote

- `catalogo_questoes_zoologia.md`: este arquivo (texto das questões, gabaritos e índice).
- `imagens/`: figuras e tabelas de cada questão, **cruas e sem edição** (`Q001_figura.png` etc.), mais as duas imagens de gabarito (`gabarito_zoologia_10.png` e `gabarito_zoologia_9.png`) para conferência.

## Como ler este arquivo

- Texto transcrito fielmente das páginas. Nada foi resumido, parafraseado, corrigido ou resolvido. Erros de digitação e de português do original foram mantidos.
- Itálicos do original aparecem entre asteriscos, como `*Arthropoda*`.
- `[FIGURA PRESENTE — imagem necessária para resolução]` marca a questão que depende de imagem. A imagem está na seção **FIGURA**, por caminho relativo (`imagens/Qxxx_figura.png`). As figuras não têm descrição em texto. Única exceção: na Q008 a tabela de alternativas também está em texto, porque são as opções de resposta.
- **Gabarito** transcrito das imagens de gabarito de cada post. Nas questões de soma, vale o número da soma, com os itens entre parênteses, como no original.
- **Escopo** é um metadado para filtrar: `Só artrópodes`, `Só equinodermos/protocordados`, `Misto` (a questão mistura outros grupos) ou `Marginal`.
- Ano da prova: só aparece na Q006. Nas demais: NÃO IDENTIFICADO.
- "Número original" é o número da questão dentro do post do blog.

## Status dos posts

| Post | Situação |
| --- | --- |
| Testes de Zoologia (10), 26/05/2016 | Completo: texto, figuras e gabarito. |
| Testes de Zoologia (9), 19/05/2016 | Completo: texto, figuras e gabarito. |
| Demais posts (2, 3, 7, 8, 13, 14, 18, 20, 21, 22, 26, 27, 29, 30, 31 e séries antigas 1/5 a 5/5) | Ainda não catalogados. |

---

# POST: TESTES DE ZOOLOGIA (10)

URL: https://djalmasantos.wordpress.com/2016/05/26/testes-de-zoologia-10/
Gabarito deste post: transcrito de `imagens/gabarito_zoologia_10.png`

---

## QUESTÃO 001

**Tema:** Artrópodes
**Escopo:** Só artrópodes
**Instituição:** UNICENTRO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 01

**ENUNCIADO**

Observe a figura, a seguir, que representa uma das hipóteses de relacionamento entre os quatro subfilos viventes do filo *Arthropoda*.

[FIGURA PRESENTE — imagem necessária para resolução]

Assinale a alternativa que corresponde, correta e respectivamente, às características adquiridas ao longo do processo evolutivo dos Arthropoda, assinaladas por I, II, III e IV, na figura.

**ALTERNATIVAS**

A) Presença de quelíceras, presença de um par de antenas, apêndices unirremes e sistema nervoso dorsal.

B) Presença de quelíceras, presença de mandíbula, apêndices birremes e respiração traqueal.

C) Presença de quelas, excreção por túbulos de Malpighi, sistema nervoso dorsal e presença de seis pernas.

D) Presença de mandíbulas, apêndices unirremes, respiração traqueal e respiração através de pulmões foliáceos.

E) Apêndices birremes, presença de mandíbulas, respiração traqueal e excreção através de glândula antenal.

**FIGURA**

![Figura da Q001](imagens/Q001_figura.png)

**GABARITO**

B

---

## QUESTÃO 002

**Tema:** Artrópodes (Insecta)
**Escopo:** Só artrópodes
**Instituição:** UPE
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 02

**ENUNCIADO**

Estabeleça a correta associação entre o inseto apresentado na figura, o respectivo tipo de desenvolvimento e a sua denominação.

[FIGURA PRESENTE — imagem necessária para resolução]

Assinale a alternativa que apresenta a associação correta.

**ALTERNATIVAS**

A) A 2 III, B 1 I e C 3 II.

B) A 1 II, B 2 III e C 3 I.

C) A 3 I, B 1 II e C 2 III.

D) A 2 II, B 3 III e C 1 I.

E) A 3 III, B 2 I e C 1 II.

**FIGURA**

![Figura da Q002](imagens/Q002_figura.png)

**GABARITO**

A

---

## QUESTÃO 003

**Tema:** Artrópodes; Equinodermos; Protocordados (questão mista)
**Escopo:** Misto
**Instituição:** UEM
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 03

**ENUNCIADO**

Assinale a(s) alternativa(s) que associa(m) corretamente o grupo zoológico a algumas de suas características.

**ALTERNATIVAS**

01. Equinodermos – possuem lanterna de Aristóteles e parapódios.

02. Artrópodos – apresentam exoesqueleto quitinoso e túbulos de Malpighi.

04. Moluscos – são constituídos de cabeça, pé e massa visceral.

08. Protocordados – possuem notocorda e fendas branquiais.

16. Aves – são amniotas e possuem siringe.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

30 (02,04,08,16)

---

## QUESTÃO 004

**Tema:** Artrópodes (inclusão marginal)
**Escopo:** Marginal
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 04

**ENUNCIADO**

Em alguns artrópodes, a carapaça externa de quitina foi uma estratégia evolutiva de sucesso para a conquista do meio terrestre, protegendo-os da dessecação (perda de água). Outros animais apresentam adaptações diferentes para contornar esse problema. Observe as alternativas a seguir e assinale aquela que não está relacionada com a dessecação.

**ALTERNATIVAS**

A) Pele com queratina nos mamíferos

B) Ovos com casca calcária nas aves

C) Glândulas secretoras de muco na pele dos sapos.

D) Escamas no corpo dos répteis

E) Esqueleto interno nos vertebrados.

**FIGURA**

Não há.

**GABARITO**

E

**OBSERVAÇÕES DE TRANSCRIÇÃO**

Inclusão marginal: o enunciado trata do exoesqueleto de quitina dos artrópodes, mas as alternativas tratam de vertebrados. Remover se o banco for restrito ao conteúdo dos três temas.

---

## QUESTÃO 005

**Tema:** Artrópodes (Insecta, Crustacea)
**Escopo:** Só artrópodes
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 06

**ENUNCIADO**

Insetos e crustáceos têm em comum:

**ALTERNATIVAS**

A) Um par de antenas.

B) O sistema circulatório do tipo aberto.

C) O sistema respiratório traqueal.

D) O sistema excretor por túbulos de Malpighi.

E) A fecundação externa.

**FIGURA**

Não há.

**GABARITO**

B

---

## QUESTÃO 006

**Tema:** Artrópodes
**Escopo:** Só artrópodes
**Instituição:** UEM
**Ano:** 2001 (aparece no enunciado do blog como "UEM-2001")
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 08

**ENUNCIADO**

Assinale o que for correto.

**ALTERNATIVAS**

01. Corpo dividido em cabeça, tórax e abdômen, três pares de pernas e um par de antenas são características da classe *Chilopoda*.

02. Os insetos com desenvolvimento do tipo holometábolo (metamorfose completa) passam pelos estágios de larva e pupa; borboletas e moscas apresentam esse tipo de desenvolvimento.

04. O exoesqueleto dos *Arthropoda* é uma das características que permitiu que alguns grupos desse filo ocupassem com sucesso o ambiente terrestre, pois ele reduz a perda de água, que é um dos principais problemas que os animais enfrentam no meio terrestre.

08. Os insetos apresentam olhos compostos, aparelhos bucais modificados de acordo com o hábito alimentar, e os órgãos excretores são os tubos de Malpighi.

16. Os integrantes da classe *Crustacea* são exclusivamente aquáticos, e a principal adaptação que apresentam a esse meio é a respiração traqueal.

32. As principais características dos *Arachnida* são quatro pares de pernas, um par de antenas, um par de mandíbulas e olhos compostos.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

14 (02,04,08)

---

## QUESTÃO 007

**Tema:** Artrópodes; Equinodermos (questão mista)
**Escopo:** Misto
**Instituição:** Alfenas
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 09

**ENUNCIADO**

Considere as características a seguir.

I. Simetria bilateral.

II. Sistema nervoso ganglionar.

III. Sistema digestório completo.

IV. Hermafroditismo.

O filo de invertebrados que possui representantes com todas as características relacionadas é um:

**ALTERNATIVAS**

A) Porífero.

B) Equinodermo.

C) Artrópodo.

D) Anelídeo.

E) Celenterado.

**FIGURA**

Não há.

**GABARITO**

D

---

## QUESTÃO 008

**Tema:** Artrópodes (Arachnida)
**Escopo:** Só artrópodes
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 10

**ENUNCIADO**

A figura abaixo mostra um animal. Assinale a alternativa da tabela que contém suas características corretas.

[FIGURA PRESENTE — imagem necessária para resolução]

**ALTERNATIVAS**

As alternativas estão numa tabela que faz parte da imagem:

| | ANTENAS | MANDÍBULAS | QUELÍCERAS | PERNAS |
| --- | --- | --- | --- | --- |
| a | 1 par | 1 par | Ausentes | 3 pares |
| b | 1 par | Ausentes | 1 par | 4 pares |
| c | 2 pares | 1 par | Ausentes | 6 pares |
| d | Ausentes | Ausentes | 1 par | 4 pares |
| e | Ausentes | 1 par | Ausentes | 5 pares |

**FIGURA**

![Figura da Q008](imagens/Q008_figura.png)

**GABARITO**

D

---

## QUESTÃO 009

**Tema:** Artrópodes (Insecta, Arachnida, Crustacea)
**Escopo:** Só artrópodes
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 12

**ENUNCIADO**

A tabela abaixo representa características de três classes de artrópodes.

[FIGURA PRESENTE — imagem necessária para resolução]

A tabela será completa se os espaços em branco (de I a IV) forem preenchidos respectivamente por: I II III IV

**ALTERNATIVAS**

A) Traqueias; 6 pares; nefrídeos; 8 pares.

B) Filotraqueias; 3 pares; túbulos de Malpighi; 4 pares.

C) Espiráculos; 8 pares; cecos anais; 8 pares;

D) Traqueias; 3 pares; túbulos de Malpighi; 4 pares.

E) Cutânea; 3 pares; pronefros; 5 pares;

**FIGURA**

![Figura da Q009](imagens/Q009_figura.png)

**GABARITO**

D

**OBSERVAÇÕES DE TRANSCRIÇÃO**

O ";" ao final das alternativas C e E está assim no original.

---

## QUESTÃO 010

**Tema:** Artrópodes (Arachnida, Crustacea, Insecta)
**Escopo:** Só artrópodes
**Instituição:** FGV
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 13

**ENUNCIADO**

A tabela apresenta características de algumas classes do filo *Arthropoda*.

[FIGURA PRESENTE — imagem necessária para resolução]

Na tabela, *Arachnida*, *Crustacea* e *Insecta* estão respectivamente representados pelos números:

**ALTERNATIVAS**

A) 1, 2 e 3.

B) 1, 3 e 2.

C) 2, 3 e 1.

D) 3, 1 e 2.

E) 3, 2 e 1.

**FIGURA**

![Figura da Q010](imagens/Q010_figura.png)

**GABARITO**

D

---

## QUESTÃO 011

**Tema:** Artrópodes (item 04); Protocordados/Cordados (item 16) (questão mista)
**Escopo:** Misto
**Instituição:** UEM
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 14

**ENUNCIADO**

Sobre algumas das características dos filos e das classes do reino animal, assinale o que for correto.

**ALTERNATIVAS**

01. Os platelmintos cestoides são destituídos de sistema digestório, o que retrata uma notável adaptação à vida parasitária.

02. A concha dos moluscos, por estar presente em todas as classes, não é utilizada como critério de classificação.

04. Uma das evidências do parentesco evolutivo entre os anelídeos e os artrópodes é o sistema circulatório fechado.

08. O tipo de desenvolvimento embrionário varia entre os mamíferos, sendo um dos aspectos que diferenciam suas três subclasses.

16. O que caracteriza um animal cordado é a presença da coluna vertebral na fase adulta.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

09 (01,08)

---

## QUESTÃO 012

**Tema:** Artrópodes (Insecta, Crustacea, Arachnida, Chilopoda, Diplopoda)
**Escopo:** Só artrópodes
**Instituição:** MACK
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 16

**ENUNCIADO**

O quadro comparativo a seguir refere-se às cinco classes de artrópodos:

[FIGURA PRESENTE — imagem necessária para resolução]

Os espaços A, B e C no quadro devem ser preenchidos respectivamente por:

**ALTERNATIVAS**

A) 1 par, traqueal, tubos de Malpighi.

B) ausentes, traqueal, glândulas verdes.

C) ausentes, pulmonar, glândulas verdes.

D) 1 par, traqueal, glândulas verdes.

E) ausentes, traqueal, tubos de Malpighi.

**FIGURA**

![Figura da Q012](imagens/Q012_figura.png)

**GABARITO**

B

---

## QUESTÃO 013

**Tema:** Equinodermos (item f, lanterna de Aristóteles) (questão mista)
**Escopo:** Misto
**Instituição:** UNIOESTE
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 18

**ENUNCIADO**

Assinale a(s) alternativa(s) em que todas as correlações entre os grupos animais e as características estão corretas.

1. Poríferos

2. Equinodermos

3. Nematódeos

4. Platelmintos

5. Moluscos

6. Cnidários

a. Triblásticos

b. Tubo digestivo incompleto

c. Tubo digestivo completo

d. Ausência de sistemas circulatório e respiratório

e. Presença de rádula e ctenídeos

f. Presença de lanterna-de-aristóteles

g. Larvas anfiblástula e parênquimula

**ALTERNATIVAS**

01. 1d, 2a, 3c, 4b.

02 2c, 3a, 5e, 6b.

04. 2f, 4a, 5c, 6g.

08. 1c, 4e, 5a, 6d.

16. 2a, 3b, 5c, 6g.

32. 2c, 3b, 4d, 5f.

64. 1d, 3b, 5f, 6b.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

03 (01,02)

**OBSERVAÇÕES DE TRANSCRIÇÃO**

A alternativa "02" está sem ponto após o número, como no original.

---

## QUESTÃO 014

**Tema:** Artrópodes
**Escopo:** Só artrópodes
**Instituição:** PUC-SP
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 19

**ENUNCIADO**

João deixou seus pais apreensivos, pois resolveu criar alguns animais nada convencionais como tarântulas, escorpiões, piolhos-de-cobra e tatuzinhos-de-jardim. A partir de seu conhecimento sobre invertebrados, João descreveu aos pais algumas características dos animais que está criando, e fez apenas uma afirmação incorreta. Assinale-a.

**ALTERNATIVAS**

A) Todos apresentam apêndices articulados.

B) Todos têm corpo revestido de exoesqueleto.

C) Todos pertencem ao filo *Arthropoda*.

D) Há aracnídeos entre eles.

E) Um deles é inseto.

**FIGURA**

Não há.

**GABARITO**

E

---

## QUESTÃO 015

**Tema:** Artrópodes
**Escopo:** Só artrópodes
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (10)
**Número original:** 20

**ENUNCIADO**

Em uma coleta na mata, um estudante capturou aranhas, formigas, besouros e escorpiões. A partir de critérios morfológicos, esses animais foram separados em dois diferentes grupos. Sobre os critérios utilizados para a separação desses animais em dois grupos, considere as afirmativas a seguir.

I. Presença ou ausência de apêndices articulados.

II. Presença ou ausência de antenas.

III. Presença ou ausência de segmentação no corpo.

IV. Presença ou ausência de quelíceras.

Estão corretas apenas as afirmativas:

**ALTERNATIVAS**

A) I e II.

B) I e III.

C) II e IV.

D) I, III e IV.

E) II, III e IV.

**FIGURA**

Não há.

**GABARITO**

C

---

# POST: TESTES DE ZOOLOGIA (9)

URL: https://djalmasantos.wordpress.com/2016/05/19/testes-de-zoologia-9/
Gabarito deste post: transcrito de `imagens/gabarito_zoologia_9.png`

---

## QUESTÃO 016

**Tema:** Artrópodes (Crustacea)
**Escopo:** Só artrópodes
**Instituição:** UECE
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 01

**ENUNCIADO**

Os crustáceos são animais invertebrados e compreendem um grupo bastante diversificado do reino animal, sendo em sua maioria marinhos. Sobre os crustáceos, é correto afirmar-se que:

**ALTERNATIVAS**

A) São animais exclusivos de ambientes aquáticos, quer sejam marinhos quer sejam de água doce.

B) Respiram exclusivamente por brânquias na fase larval.

C) Possuem exoesqueleto articulado e impregnado de lignina, por isso possuem carapaças rígidas e resistentes.

D) Em sua maioria, a cabeça e o tórax estão fundidos em uma peça única denominada cefalotórax.

**FIGURA**

Não há.

**GABARITO**

D

**OBSERVAÇÕES DE TRANSCRIÇÃO**

A página lista apenas as alternativas a) a d).

---

## QUESTÃO 017

**Tema:** Artrópodes (inclusão marginal)
**Escopo:** Marginal
**Instituição:** FATEC
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 05

**ENUNCIADO**

Em uma aula de laboratório, um grupo de alunos recebeu a tarefa de analisar um animal para descobrir a que grupo de classificação pertencia. A chave de classificação abaixo foi utilizada a fim de orientar a pesquisa.

[FIGURA PRESENTE — imagem necessária para resolução]

O grupo de estudantes chegou à conclusão de que o animal pertencia ao grupo 5. Esse animal pode ser uma:

**ALTERNATIVAS**

A) Lombriga.

B) Planária.

C) Abelha.

D) Minhoca.

E) Anêmona-do-mar.

**FIGURA**

![Figura da Q017](imagens/Q017_figura.png)

**GABARITO**

D

**OBSERVAÇÕES DE TRANSCRIÇÃO**

Inclusão marginal: a única relação com os temas é a alternativa "Abelha" (artrópode).

---

## QUESTÃO 018

**Tema:** Artrópodes (questão mista)
**Escopo:** Misto
**Instituição:** IFPE
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 08

**ENUNCIADO**

Um estudante recebeu uma tarefa de seu professor: dar um passeio pelos jardins da Escola e realizar a coleta de quatro organismos pertencentes ao Reino Metazoa e que fizesse a classificação de cada um, indicando os seus respectivos Filos. O estudante coletou os quatro organismos, numerando-os de 1 a 4. Os organismos coletados encontram-se numerados e representados pelas figuras abaixo.

[FIGURA PRESENTE — imagem necessária para resolução]

A alternativa que apresenta a identificação feita pelo aluno, correta e respectivamente de acordo com a numeração, é:

**ALTERNATIVAS**

A) (1) Filo Chordata; (2) Filo Mollusca; (3) Filo Arthropoda e (4) Filo Arthropoda.

B) (1) Filo Arthropoda; (2) Filo Mollusca; (3) Filo Chordata e (4) Filo Arthropoda.

C) (1) Filo Chordata; (2) Filo Mollusca; (3) Filo Arthropoda e (4) Filo Insecta.

D) (1) Filo Chordata; (2) Filo Gastropoda; (3) Filo Arachinida e (4) Filo Insecta.

E) (1) Filo Mollusca; (2) Filo Chordata; (3) Filo Arthropoda e (4) Filo Arthropoda.

**FIGURA**

![Figura da Q018](imagens/Q018_figura.png)

**GABARITO**

A

**OBSERVAÇÕES DE TRANSCRIÇÃO**

"Arachinida" (alternativa D) está assim no original.

---

## QUESTÃO 019

**Tema:** Equinodermos
**Escopo:** Só equinodermos/protocordados
**Instituição:** UNICENTRO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 12

**ENUNCIADO**

Os equinodermas são animais deuterostomados marinhos, com um endoesqueleto formado por placas e espinhos, que apresentam um sistema hidrovascular característico. Em relação a seus hábitos alimentares, podem ser predadores, herbívoros, necrófagos, detritívoros ou filtradores. Assinale a alternativa que apresenta, corretamente, a classe de Echinodermata que possui, no interior da carapaça, um complexo mecanismo mastigador denominado lanterna de Aristóteles.

**ALTERNATIVAS**

A) Asteroidea.

B) Crinoidea.

C) Ophiuroidea.

D) Echinoidea.

E) Holothuroidea.

**FIGURA**

Não há.

**GABARITO**

D

---

## QUESTÃO 020

**Tema:** Equinodermos; Protocordados
**Escopo:** Só equinodermos/protocordados
**Instituição:** UEPG
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 13

**ENUNCIADO**

Com base nos seus conhecimentos de características gerais e aspectos anatômicos e fisiológicos dos equinodermos e protocordados, assinale o que for correto.

**ALTERNATIVAS**

01. Os equinodermos são animais marinhos que apresentam, em geral, espinhos na superfície do corpo. Entre os representantes mais conhecidos dos equinodermos estão as estrelas-do-mar, os ouriços-do-mar, as bolachas-de-praia e os pepinos-do-mar.

02. Os equinodermos apresentam estruturas esqueléticas (ossículos) de origem endodérmica aderidas na face externa da epiderme, constituindo assim um exoesqueleto.

04. A região anterior de um anfioxo (cefalocordado) é facilmente reconhecida pela presença da boca. Essa é rodeada por longos filamentos denominados cirros bucais, que atuam como filtros, impedindo a entrada de grandes partículas.

08. Urocordados e cefalocordados não têm crânio nem coluna vertebral, sendo, por isso, chamados de protocordados.

16. As larvas dos equinodermos apresentam simetria radial enquanto os adultos têm a simetria bilateral.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

13 (01,04,08)

---

## QUESTÃO 021

**Tema:** Artrópodes (item 04); Protocordados/Cordados (item 16) (questão mista)
**Escopo:** Misto
**Instituição:** UEM
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 14

**ENUNCIADO**

Reino Animalia é o maior e mais diversificado do mundo vivo, com mais de um milhão de espécies. Sobre esses organismos, assinale a(s) alternativa(s) correta(s).

**ALTERNATIVAS**

01. Os platelmintos, por serem diblásticos, têm sistema digestório incompleto e não têm sistema excretor.

02. Muitos cnidários hidrozoários apresentam alternância de gerações, sendo que a fase polipoide se reproduz assexuadamente e a meduzoide se reproduz sexuadamente.

04. O corpo dos artrópodos é revestido externamente pela cutícula secretada pelas fiandeiras, formando o exoesqueleto.

08. A maioria dos répteis inclui animais dioicos e ovíparos, corpo coberto por queratina e pulmões eficientes.

16. A metameria, presente em moluscos, artrópodos e cordados, é vantajosa pois possibilita o processo de cefalização.

Soma das alternativas corretas:

**FIGURA**

Não há.

**GABARITO**

10 (02,08)

---

## QUESTÃO 022

**Tema:** Artrópodes (questão mista)
**Escopo:** Misto
**Instituição:** UFRN
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 16

**ENUNCIADO**

As figuras a seguir representam animais invertebrados de três filos distintos.

[FIGURA PRESENTE — imagem necessária para resolução]

Cada filo possui uma característica presente em todos os representantes de sua espécie. Os filos representados e suas características são:

**ALTERNATIVAS**

A) I – Filo Annelida, simetria bilateral; II – Filo Arthropoda, respiração cutânea; III – Filo Mollusca, patas articuladas.

B) I – Filo Annelida, respiração branquial; II – Filo Mollusca, animais de corpo mole; III – Filo Arthropoda, patas articuladas.

C) I – Filo Mollusca, animais de corpo mole; II – Filo Annelida, apresenta corpo com simetria bilateral; III – Filo Arthropoda, apresenta exoesqueleto.

D) I – Filo Mollusca, animais de corpo mole; II – Filo Annelida, apresenta exoesqueleto; III – Filo Arthropoda, simetria bilateral.

**FIGURA**

![Figura da Q022](imagens/Q022_figura.png)

**GABARITO**

C

**OBSERVAÇÕES DE TRANSCRIÇÃO**

A página lista apenas as alternativas a) a d). "sua espécie" no enunciado está assim no original.

---

## QUESTÃO 023

**Tema:** Protocordados (características gerais dos cordados)
**Escopo:** Só equinodermos/protocordados
**Instituição:** UFT
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 17

**ENUNCIADO**

Em relação ao Filo Chordata e ao desenvolvimento da notocorda, são características comuns aos subfilos Urochordata, Cephalochordata e Craniata, exceto:

**ALTERNATIVAS**

A) A presença de tubo nervoso dorsal.

B) A presença de fendas faringianas.

C) A presença de cauda pós-anal.

D) A presença de endoesqueleto.

E) A presença de notocorda.

**FIGURA**

Não há.

**GABARITO**

D

---

## QUESTÃO 024

**Tema:** Artrópodes (crescimento corporal) (questão mista)
**Escopo:** Misto
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 19

**ENUNCIADO**

Assinale a alternativa correta que associa os gráficos de crescimento corporal I e II aos animais correspondentes, respectivamente.

[FIGURA PRESENTE — imagem necessária para resolução]

**ALTERNATIVAS**

A) Cordado e quelicerado.

B) Cordado e mamífero.

C) Artrópode unirâmio e quelicerado.

D) Crustáceo e cordado.

E) Miriápode e ave.

**FIGURA**

![Figura da Q024](imagens/Q024_figura.png)

**GABARITO**

A

---

## QUESTÃO 025

**Tema:** Artrópodes (circulação, gafanhoto) (questão mista)
**Escopo:** Misto
**Instituição:** NÃO IDENTIFICADO
**Ano:** NÃO IDENTIFICADO
**Fonte:** Blog do Prof. Djalma Santos, Testes de Zoologia (9)
**Número original:** 20

**ENUNCIADO**

O sistema circulatório da minhoca, do gafanhoto, do mexilhão e do tubarão é, respectivamente:

**ALTERNATIVAS**

A) Fechado, aberto, aberto e fechado.

B) Fechado, aberto, aberto e aberto.

C) Aberto, fechado, aberto e fechado.

D) Aberto, aberto, fechado e aberto.

E) Lacunar, fechado, fechado e lacunar.

**FIGURA**

Não há.

**GABARITO**

A

---

---

# ÍNDICE

| ID | Post | Escopo | Tema | Instituição | Ano | Nº | Gabarito | Figura |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Q001 | Zool. 10 | Só artrópodes | Artrópodes | UNICENTRO | NÃO IDENTIFICADO | 01 | B | imagens/Q001_figura.png |
| Q002 | Zool. 10 | Só artrópodes | Artrópodes (Insecta) | UPE | NÃO IDENTIFICADO | 02 | A | imagens/Q002_figura.png |
| Q003 | Zool. 10 | Misto | Artrópodes; Equinodermos; Protocordados | UEM | NÃO IDENTIFICADO | 03 | 30 (02,04,08,16) | Não |
| Q004 | Zool. 10 | Marginal | Artrópodes (marginal) | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 04 | E | Não |
| Q005 | Zool. 10 | Só artrópodes | Artrópodes | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 06 | B | Não |
| Q006 | Zool. 10 | Só artrópodes | Artrópodes | UEM | 2001 | 08 | 14 (02,04,08) | Não |
| Q007 | Zool. 10 | Misto | Artrópodes; Equinodermos | Alfenas | NÃO IDENTIFICADO | 09 | D | Não |
| Q008 | Zool. 10 | Só artrópodes | Artrópodes (Arachnida) | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 10 | D | imagens/Q008_figura.png |
| Q009 | Zool. 10 | Só artrópodes | Artrópodes | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 12 | D | imagens/Q009_figura.png |
| Q010 | Zool. 10 | Só artrópodes | Artrópodes | FGV | NÃO IDENTIFICADO | 13 | D | imagens/Q010_figura.png |
| Q011 | Zool. 10 | Misto | Artrópodes; Cordados | UEM | NÃO IDENTIFICADO | 14 | 09 (01,08) | Não |
| Q012 | Zool. 10 | Só artrópodes | Artrópodes | MACK | NÃO IDENTIFICADO | 16 | B | imagens/Q012_figura.png |
| Q013 | Zool. 10 | Misto | Equinodermos (misto) | UNIOESTE | NÃO IDENTIFICADO | 18 | 03 (01,02) | Não |
| Q014 | Zool. 10 | Só artrópodes | Artrópodes | PUC-SP | NÃO IDENTIFICADO | 19 | E | Não |
| Q015 | Zool. 10 | Só artrópodes | Artrópodes | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 20 | C | Não |
| Q016 | Zool. 9 | Só artrópodes | Artrópodes (Crustacea) | UECE | NÃO IDENTIFICADO | 01 | D | Não |
| Q017 | Zool. 9 | Marginal | Artrópodes (marginal) | FATEC | NÃO IDENTIFICADO | 05 | D | imagens/Q017_figura.png |
| Q018 | Zool. 9 | Misto | Artrópodes (misto) | IFPE | NÃO IDENTIFICADO | 08 | A | imagens/Q018_figura.png |
| Q019 | Zool. 9 | Só equinodermos/protocordados | Equinodermos | UNICENTRO | NÃO IDENTIFICADO | 12 | D | Não |
| Q020 | Zool. 9 | Só equinodermos/protocordados | Equinodermos; Protocordados | UEPG | NÃO IDENTIFICADO | 13 | 13 (01,04,08) | Não |
| Q021 | Zool. 9 | Misto | Artrópodes; Cordados | UEM | NÃO IDENTIFICADO | 14 | 10 (02,08) | Não |
| Q022 | Zool. 9 | Misto | Artrópodes (misto) | UFRN | NÃO IDENTIFICADO | 16 | C | imagens/Q022_figura.png |
| Q023 | Zool. 9 | Só equinodermos/protocordados | Protocordados (Chordata) | UFT | NÃO IDENTIFICADO | 17 | D | Não |
| Q024 | Zool. 9 | Misto | Artrópodes (crescimento) | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 19 | A | imagens/Q024_figura.png |
| Q025 | Zool. 9 | Misto | Artrópodes (circulação) | NÃO IDENTIFICADO | NÃO IDENTIFICADO | 20 | A | Não |

Contagem por escopo: 11 só artrópodes, 3 só equinodermos/protocordados, 9 mistas, 2 marginais (Q004 e Q017).

---

# QUESTÕES LIDAS E NÃO CATALOGADAS (fora dos três temas)

- **Zoologia (10):** números 05 (marsúpio), 07 (dentição das cobras), 11 (moluscos gastrópodes), 15 (pombo e gato), 17 (poríferos).
- **Zoologia (9):** números 02, 03, 04, 06, 07, 09, 10, 11, 15 e 18 (vertebrados, moluscos, platelmintos e nematelmintos, sem conteúdo dos três temas).
